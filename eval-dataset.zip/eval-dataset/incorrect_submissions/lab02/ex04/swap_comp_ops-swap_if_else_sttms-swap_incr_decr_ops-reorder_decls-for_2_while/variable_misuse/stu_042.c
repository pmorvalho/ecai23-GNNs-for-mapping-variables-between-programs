#include <stdio.h>
int main()
{
  int b;
  int c;
  int a;
  scanf("%d%d%d", &a, &b, &c);
  if ((a >= b) && (c <= a))
  {
    if (!(c <= b))
    {
      printf("%d %d %d\n", b, c, a);
    }
    else
    {
      printf("%d %d %d\n", c, c, a);
    }
  }
  else
  {
    if ((b >= a) && (c <= b))
    {
      if (c <= a)
      {
        printf("%d %d %d\n", c, a, b);
      }
      else
      {
        printf("%d %d %d\n", a, c, b);
      }
    }
    else
    {
      if (b <= a)
      {
        printf("%d %d %d\n", b, a, c);
      }
      else
      {
        printf("%d %d %d\n", a, b, c);
      }
    }
  }
  return 0;
}

