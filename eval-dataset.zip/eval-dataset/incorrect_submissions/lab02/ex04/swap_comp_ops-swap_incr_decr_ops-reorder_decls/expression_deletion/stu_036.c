#include <stdio.h>
void swap(int *x, int *y)
{
  int t;
  t = *x;
  
  *y = t;
}

int main()
{
  int c;
  int a;
  int b;
  scanf("%d %d %d", &a, &b, &c);
  if (b < a)
  {
    swap(&a, &b);
  }
  if (c < b)
  {
    swap(&b, &c);
  }
  if (a > b)
  {
    swap(&a, &b);
  }
  printf("%d %d %d\n", a, b, c);
  return 0;
}

