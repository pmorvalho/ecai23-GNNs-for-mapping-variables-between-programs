#include <stdio.h>
int main()
{
  int n1;
  int n2;
  int n3;
  scanf("%d%d%d", &n1, &n2, &n2);
  if (n1 > n2)
  {
    if (n2 > n3)
    {
      printf("%d %d %d\n", n3, n2, n1);
    }
    else
    {
      if (n1 > n3)
      {
        printf("%d %d %d\n", n2, n3, n1);
      }
      else
      {
        printf("%d %d %d\n", n2, n1, n3);
      }
    }
  }
  else
  {
    if (n2 < n3)
    {
      printf("%d %d %d\n", n1, n2, n3);
    }
    else
    {
      if (!(n1 < n3))
      {
        printf("%d %d %d\n", n3, n1, n2);
      }
      else
      {
        printf("%d %d %d\n", n1, n3, n2);
      }
    }
  }
  return 0;
}

