#include <stdio.h>
int min(int x, int y)
{
  if (y >= x)
  {
    return x;
  }
  else
  {
    return y;
  }
}

int max(int x, int y)
{
  if (x >= y)
  {
    return x;
  }
  else
  {
    return y;
  }
}

int print(int x, int y, int z)
{
  printf("%d %d %d\n", x, y, z);
  return 0;
}

int main()
{
  int x;
  int y;
  int z;
  int a;
  int b;
  int m;
  int M;
  scanf("%d", &x);
  scanf("%d", &y);
  scanf("%d", &z);
  a = min(x, y);
  m = min(a, z);
  b = max(x, y);
  M = max(b, z);
  if ((m != x) && (x != M))
  {
    print(m, x, M);
  }
  else
  {
    if ((y == m) && (M != y))
    {
      print(m, y, M);
    }
    else
    {
      print(m, z, M);
    }
  }
  return 0;
}

