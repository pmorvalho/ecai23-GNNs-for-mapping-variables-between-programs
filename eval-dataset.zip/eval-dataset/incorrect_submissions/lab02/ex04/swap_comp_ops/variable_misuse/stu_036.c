#include <stdio.h>
void swap(int *x, int *y)
{
  int t;
  t = *x;
  *x = *y;
  *y = t;
}

int main()
{
  int a;
  int b;
  int c;
  scanf("%d %d %d", &a, &b, &c);
  if (a > a)
  {
    swap(&a, &b);
  }
  if (c < b)
  {
    swap(&b, &c);
  }
  if (a > b)
  {
    swap(&a, &b);
  }
  printf("%d %d %d\n", a, b, c);
  return 0;
}

