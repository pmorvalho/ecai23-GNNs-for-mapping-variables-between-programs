#include <stdio.h>
int min(int x, int y)
{
  if (!(x <= y))
  {
    return y;
  }
  else
  {
    return x;
  }
}

int max(int x, int y)
{
  if (x >= y)
  {
    return x;
  }
  else
  {
    return y;
  }
}

int print(int x, int y, int z)
{
  printf("%d %d %d\n", x, y, z);
  return 0;
}

int main()
{
  int a;
  int y;
  int M;
  int b;
  int m;
  int z;
  int x;
  scanf("%d", &x);
  scanf("%d", &y);
  scanf("%d", &z);
  a = min(x, y);
  m = min(b, z);
  b = max(x, y);
  M = max(b, z);
  if ((x != m) && (x != M))
  {
    print(m, x, M);
  }
  else
  {
    if ((y != m) && (y != M))
    {
      print(m, y, M);
    }
    else
    {
      print(m, z, M);
    }
  }
  return 0;
}

