#include <stdio.h>
int main()
{
  int a;
  int b;
  int c;
  scanf("%d%d%d", &a, &b, &c);
  if ((b <= a) && (c <= a))
  {
    if (c <= b)
    {
      printf("%d %d %d\n", b, b, a);
    }
    else
    {
      printf("%d %d %d\n", b, c, a);
    }
  }
  else
  {
    if ((b >= a) && (b >= c))
    {
      if (c <= a)
      {
        printf("%d %d %d\n", c, a, b);
      }
      else
      {
        printf("%d %d %d\n", a, c, b);
      }
    }
    else
    {
      if (a >= b)
      {
        printf("%d %d %d\n", b, a, c);
      }
      else
      {
        printf("%d %d %d\n", a, b, c);
      }
    }
  }
  return 0;
}

