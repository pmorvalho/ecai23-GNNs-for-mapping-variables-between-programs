#include <stdio.h>
int main()
{
  int c;
  int a;
  int b;
  scanf("%d%d%d", &a, &b, &c);
  if ((b >= a) && (a <= c))
  {
    printf("%d ", a);
    if (c >= b)
    {
      printf("%d %d\n", b, c);
    }
    else
    {
      printf("%d %d\n", c, b);
    }
  }
  else
  {
    if ((b <= a) && (c >= b))
    {
      printf("%d ", b);
      if (a <= c)
      {
        printf("%d %d\n", a, c);
      }
      else
      {
        printf("%d %d\n", c, a);
      }
    }
    else
    {
      if (b >= a)
      {
        printf("%d %d %d\n", c, a, b);
      }
      else
      {
        printf("%d %d %d\n", c, a, a);
      }
    }
  }
  return 0;
}

