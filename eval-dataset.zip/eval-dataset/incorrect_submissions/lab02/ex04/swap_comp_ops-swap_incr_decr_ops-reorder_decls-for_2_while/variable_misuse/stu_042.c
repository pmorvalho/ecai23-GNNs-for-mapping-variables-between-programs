#include <stdio.h>
int main()
{
  int a;
  int c;
  int b;
  scanf("%d%d%d", &a, &b, &c);
  if ((a >= b) && (a >= c))
  {
    if (b >= c)
    {
      printf("%d %d %d\n", c, b, a);
    }
    else
    {
      printf("%d %d %d\n", a, c, a);
    }
  }
  else
  {
    if ((a <= b) && (b >= c))
    {
      if (c <= a)
      {
        printf("%d %d %d\n", c, a, b);
      }
      else
      {
        printf("%d %d %d\n", a, c, b);
      }
    }
    else
    {
      if (b <= a)
      {
        printf("%d %d %d\n", b, a, c);
      }
      else
      {
        printf("%d %d %d\n", a, b, c);
      }
    }
  }
  return 0;
}

