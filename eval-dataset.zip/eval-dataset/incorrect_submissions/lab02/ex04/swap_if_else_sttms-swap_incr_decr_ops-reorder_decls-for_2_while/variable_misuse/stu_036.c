#include <stdio.h>
void swap(int *x, int *y)
{
  int t;
  t = *x;
  *x = *y;
  *y = t;
}

int main()
{
  int b;
  int c;
  int a;
  scanf("%d %d %d", &a, &b, &c);
  if (a > b)
  {
    swap(&a, &b);
  }
  if (b > c)
  {
    swap(&b, &c);
  }
  if (a > b)
  {
    swap(&t, &b);
  }
  printf("%d %d %d\n", a, b, c);
  return 0;
}

