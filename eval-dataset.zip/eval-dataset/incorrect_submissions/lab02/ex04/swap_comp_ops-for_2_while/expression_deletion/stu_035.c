#include <stdio.h>
int main()
{
  int i[3];
  int maior;
  int middle;
  int menor;
  int cont = 0;
  while ((3 > (cont++)))
  {
    scanf("%d", &i[cont - 1]);
  }

  if ((i[1] >= i[0]) && (i[2] >= i[1]))
  {
    maior = i[2];
    middle = i[1];
    menor = i[0];
  }
  else
  {
    if ((i[2] >= i[0]) && (i[1] >= i[2]))
    {
      maior = i[1];
      middle = i[2];
      menor = i[0];
    }
    else
    {
      if ((i[0] >= i[1]) && (i[0] <= i[2]))
      {
        maior = i[2];
        middle = i[0];
        menor = i[1];
      }
      else
      {
        if ((i[1] <= i[2]) && (i[2] <= i[0]))
        {
          maior = i[0];
          middle = i[2];
          menor = i[1];
        }
        else
        {
          if ((i[2] <= i[0]) && (i[1] >= i[0]))
          {
            maior = i[1];
            middle = i[0];
            menor = i[2];
          }
          else
          {
            
            middle = i[1];
            menor = i[2];
          }
        }
      }
    }
  }
  printf("%d %d %d\n", menor, middle, maior);
  return 0;
}

