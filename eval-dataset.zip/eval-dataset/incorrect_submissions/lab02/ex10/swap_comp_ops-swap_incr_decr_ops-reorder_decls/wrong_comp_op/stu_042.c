#include <stdio.h>
int main()
{
  int soma = 0;
  int contador = 0;
  int n;
  scanf("%d", &n);
  while ((n == 0))
  {
    soma += n % 10;
    n = n / 10;
    contador++;
  }

  printf("%d\n%d\n", contador, soma);
  return 0;
}

