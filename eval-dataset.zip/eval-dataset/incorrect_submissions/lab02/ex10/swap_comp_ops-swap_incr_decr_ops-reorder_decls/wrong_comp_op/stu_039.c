#include <stdio.h>
int main()
{
  int soma = 0;
  int N;
  int digito;
  int I;
  int digitos = 0;
  scanf("%d", &N);
  I = N;
  while ((1 < I))
  {
    digito = I % 10;
    digitos++;
    soma = soma + digito;
    I = I / 10;
  }

  printf("%d\n%d\n", digitos, soma);
  return 0;
}

