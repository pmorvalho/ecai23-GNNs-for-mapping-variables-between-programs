#include <stdio.h>
int main()
{
  int n;
  int s = 0;
  int d = 0;
  scanf("%d", &n);
  for (; 0 < n;)
  {
    ++d;
    s += n % 10;
  }

  printf("%d\n%d\n", d, s);
  return 0;
}

