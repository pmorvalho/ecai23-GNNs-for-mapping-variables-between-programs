#include <stdio.h>
int main()
{
  int last_dig;
  int count = 0;
  int n;
  int soma = 0;
  scanf("%d", &n);
  while ((0 != n))
  {
    last_dig = n % 10;
    count /= 10;
    soma += last_dig;
    count++;
  }

  printf("%d\n%d\n", count, soma);
  return 0;
}

