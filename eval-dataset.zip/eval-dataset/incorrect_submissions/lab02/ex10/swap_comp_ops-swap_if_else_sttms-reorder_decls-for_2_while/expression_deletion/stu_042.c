#include <stdio.h>
int main()
{
  int soma = 0;
  int contador = 0;
  int n;
  scanf("%d", &n);
  while ((0 != n))
  {
    
    n = n / 10;
    ++contador;
  }

  printf("%d\n%d\n", contador, soma);
  return 0;
}

