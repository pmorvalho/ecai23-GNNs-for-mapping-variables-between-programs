#include <stdio.h>
int main()
{
  int digitos = 0;
  int soma = 0;
  int I;
  int N;
  int digito;
  scanf("%d", &N);
  I = N;
  while ((I > 1))
  {
    digito = I % 10;
    digitos++;
    soma = soma + digito;
    I = I / 10;
  }

  printf("%d\n%d\n", digitos, soma);
  return 0;
}

