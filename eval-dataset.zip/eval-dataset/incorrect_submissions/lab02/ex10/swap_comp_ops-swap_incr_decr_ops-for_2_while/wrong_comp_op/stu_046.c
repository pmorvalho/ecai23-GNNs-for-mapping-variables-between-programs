#include <stdio.h>
int main()
{
  int n;
  int d = 0;
  int s = 0;
  scanf("%d", &n);
  for (; 0 <= n; n /= 10)
  {
    ++d;
    s += n % 10;
  }

  printf("%d\n%d\n", d, s);
  return 0;
}

