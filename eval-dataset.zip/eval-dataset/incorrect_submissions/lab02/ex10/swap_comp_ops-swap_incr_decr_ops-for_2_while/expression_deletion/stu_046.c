#include <stdio.h>
int main()
{
  int n;
  int d = 0;
  int s = 0;
  scanf("%d", &n);
  for (; n > 0; n /= 10)
  {
    ++d;
    
  }

  printf("%d\n%d\n", d, s);
  return 0;
}

