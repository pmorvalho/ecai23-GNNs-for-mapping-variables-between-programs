#include <stdio.h>
int main()
{
  int N;
  int Digitos = 0;
  int M;
  int S = 0;
  scanf("%d", &N);
  while ((0 < N))
  {
    Digitos++;
    M = N % 10;
    
    S = S + M;
  }

  printf("%d\n", Digitos);
  printf("%d\n", S);
  return 0;
}

