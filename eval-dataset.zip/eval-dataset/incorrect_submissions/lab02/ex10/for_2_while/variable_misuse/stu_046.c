#include <stdio.h>
int main()
{
  int n;
  int d = 0;
  int s = 0;
  scanf("%d", &n);
  while ((n > 0))
  {
    d++;
    s += n % 10;
    n /= 10;
  }

  printf("%d\n%d\n", s, s);
  return 0;
}

