#include <stdio.h>
int main()
{
  int n;
  int contador = 0;
  int soma = 0;
  scanf("%d", &n);
  while ((0 != n))
  {
    soma += n % 10;
    n = n / 10;
    ++contador;
  }

  printf("%d\n%d\n", contador, n);
  return 0;
}

