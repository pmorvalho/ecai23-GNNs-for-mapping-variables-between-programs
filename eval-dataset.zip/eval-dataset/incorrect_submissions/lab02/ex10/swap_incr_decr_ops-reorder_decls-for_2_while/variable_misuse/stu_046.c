#include <stdio.h>
int main()
{
  int d = 0;
  int n;
  int s = 0;
  scanf("%d", &n);
  for (; n > 0; n /= 10)
  {
    ++s;
    s += n % 10;
  }

  printf("%d\n%d\n", d, s);
  return 0;
}

