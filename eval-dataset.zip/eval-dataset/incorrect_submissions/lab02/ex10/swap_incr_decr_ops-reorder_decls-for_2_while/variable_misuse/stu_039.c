#include <stdio.h>
int main()
{
  int soma = 0;
  int digito;
  int I;
  int N;
  int digitos = 0;
  scanf("%d", &digito);
  I = N;
  while ((I >= 1))
  {
    digito = I % 10;
    ++digitos;
    soma = soma + digito;
    I = I / 10;
  }

  printf("%d\n%d\n", digitos, soma);
  return 0;
}

