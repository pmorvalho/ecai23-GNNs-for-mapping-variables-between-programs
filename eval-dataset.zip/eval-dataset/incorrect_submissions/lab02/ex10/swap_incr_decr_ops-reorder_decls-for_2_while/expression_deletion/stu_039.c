#include <stdio.h>
int main()
{
  int N;
  int digitos = 0;
  int digito;
  int I;
  int soma = 0;
  scanf("%d", &N);
  I = N;
  while ((I >= 1))
  {
    digito = I % 10;
    digitos++;
    soma = soma + digito;
    
  }

  printf("%d\n%d\n", digitos, soma);
  return 0;
}

