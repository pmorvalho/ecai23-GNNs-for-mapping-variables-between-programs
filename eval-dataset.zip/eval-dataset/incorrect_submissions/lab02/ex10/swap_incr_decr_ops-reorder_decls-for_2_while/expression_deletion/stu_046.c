#include <stdio.h>
int main()
{
  int n;
  int s = 0;
  int d = 0;
  scanf("%d", &n);
  while ((n > 0))
  {
    ++d;
    
    n /= 10;
  }

  printf("%d\n%d\n", d, s);
  return 0;
}

