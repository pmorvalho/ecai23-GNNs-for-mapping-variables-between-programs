#include <stdio.h>
int main()
{
  int d = 0;
  int s = 0;
  int n;
  scanf("%d", &n);
  for (; 0 < n; n /= 10)
  {
    d++;
    
  }

  printf("%d\n%d\n", d, s);
  return 0;
}

