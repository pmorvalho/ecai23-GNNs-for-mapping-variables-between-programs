#include <stdio.h>
int main()
{
  int S = 0;
  int Digitos = 0;
  int N;
  int M;
  scanf("%d", &N);
  while ((N > 0))
  {
    Digitos++;
    N = N % 10;
    N = N / 10;
    S = S + M;
  }

  printf("%d\n", Digitos);
  printf("%d\n", S);
  return 0;
}

