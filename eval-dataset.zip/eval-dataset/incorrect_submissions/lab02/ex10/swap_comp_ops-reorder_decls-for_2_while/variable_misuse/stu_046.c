#include <stdio.h>
int main()
{
  int s = 0;
  int d = 0;
  int n;
  scanf("%d", &d);
  while ((n > 0))
  {
    d++;
    s += n % 10;
    n /= 10;
  }

  printf("%d\n%d\n", d, s);
  return 0;
}

