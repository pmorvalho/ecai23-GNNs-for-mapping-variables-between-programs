#include <stdio.h>
int main()
{
  int Digitos = 0;
  int M;
  int N;
  int S = 0;
  scanf("%d", &N);
  while ((N >= 0))
  {
    Digitos++;
    M = N % 10;
    N = N / 10;
    S = S + M;
  }

  printf("%d\n", Digitos);
  printf("%d\n", S);
  return 0;
}

