#include <stdio.h>
int main()
{
  int d = 0;
  int n;
  int s = 0;
  scanf("%d", &n);
  for (; 0 < n;)
  {
    ++d;
    s += n % 10;
  }

  printf("%d\n%d\n", d, s);
  return 0;
}

