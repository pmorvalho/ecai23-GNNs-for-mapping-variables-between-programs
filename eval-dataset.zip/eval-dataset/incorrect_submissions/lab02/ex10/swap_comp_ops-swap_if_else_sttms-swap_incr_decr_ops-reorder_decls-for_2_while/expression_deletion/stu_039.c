#include <stdio.h>
int main()
{
  int N;
  int I;
  int soma = 0;
  int digitos = 0;
  int digito;
  scanf("%d", &N);
  
  while ((I >= 1))
  {
    digito = I % 10;
    ++digitos;
    soma = soma + digito;
    I = I / 10;
  }

  printf("%d\n%d\n", digitos, soma);
  return 0;
}

