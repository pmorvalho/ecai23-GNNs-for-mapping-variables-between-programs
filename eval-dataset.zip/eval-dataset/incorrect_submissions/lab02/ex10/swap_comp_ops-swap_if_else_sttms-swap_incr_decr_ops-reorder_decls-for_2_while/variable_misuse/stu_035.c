#include <stdio.h>
int main()
{
  int n;
  int last_dig;
  int count = 0;
  int soma = 0;
  scanf("%d", &n);
  while ((0 != n))
  {
    last_dig = count % 10;
    n /= 10;
    soma += last_dig;
    count++;
  }

  printf("%d\n%d\n", count, soma);
  return 0;
}

