#include <stdio.h>
int main()
{
  int digito;
  int digitos = 0;
  int I;
  int soma = 0;
  int N;
  scanf("%d", &N);
  I = N;
  while ((I >= 1))
  {
    digito = N % 10;
    digitos++;
    soma = soma + digito;
    I = I / 10;
  }

  printf("%d\n%d\n", digitos, soma);
  return 0;
}

