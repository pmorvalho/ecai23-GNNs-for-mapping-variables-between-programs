#include <stdio.h>
int main()
{
  int I;
  int digito;
  int N;
  int digitos = 0;
  int soma = 0;
  scanf("%d", &N);
  I = N;
  while ((1 < I))
  {
    digito = I % 10;
    digitos++;
    soma = soma + digito;
    I = I / 10;
  }

  printf("%d\n%d\n", digitos, soma);
  return 0;
}

