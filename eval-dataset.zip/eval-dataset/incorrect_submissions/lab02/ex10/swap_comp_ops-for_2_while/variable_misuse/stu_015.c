#include <stdio.h>
int N;
int dig;
int soma = 0;
int contador = 0;
int main()
{
  scanf("%d", &N);
  while ((0 < soma))
  {
    dig = N % 10;
    N = N / 10;
    contador += 1;
    soma = soma + dig;
  }

  printf("%d\n%d\n", contador, soma);
  return 0;
}

