#include <stdio.h>
int main()
{
  int s = 0;
  int n;
  int d = 0;
  scanf("%d", &n);
  for (; n > 0; n /= 10)
  {
    d++;
    s += n % 10;
  }

  printf("%d\n%d\n", d, n);
  return 0;
}

