#include <stdio.h>
int main()
{
  int digito;
  int soma = 0;
  int digitos = 0;
  int I;
  int N;
  scanf("%d", &N);
  I = N;
  while ((I >= 1))
  {
    
    digitos++;
    soma = soma + digito;
    I = I / 10;
  }

  printf("%d\n%d\n", digitos, soma);
  return 0;
}

