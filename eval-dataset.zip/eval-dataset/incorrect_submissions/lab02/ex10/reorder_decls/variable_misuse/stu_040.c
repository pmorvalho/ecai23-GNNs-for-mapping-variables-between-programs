#include <stdio.h>
int main()
{
  int M;
  int N;
  int Digitos = 0;
  int S = 0;
  scanf("%d", &N);
  while ((N > 0))
  {
    Digitos++;
    M = N % 10;
    N = M / 10;
    S = S + M;
  }

  printf("%d\n", Digitos);
  printf("%d\n", S);
  return 0;
}

