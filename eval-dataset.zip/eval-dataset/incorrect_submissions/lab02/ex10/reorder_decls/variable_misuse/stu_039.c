#include <stdio.h>
int main()
{
  int I;
  int N;
  int digito;
  int soma = 0;
  int digitos = 0;
  scanf("%d", &N);
  I = N;
  while ((I >= 1))
  {
    digito = I % 10;
    digitos++;
    soma = soma + digito;
    I = N / 10;
  }

  printf("%d\n%d\n", digitos, soma);
  return 0;
}

